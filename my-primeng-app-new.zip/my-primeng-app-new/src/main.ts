
import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { AppComponent } from './app/app.component';
import { USER_CONTEXT } from './app/shared/user-context.token';





bootstrapApplication(AppComponent, appConfig).catch(console.error);
