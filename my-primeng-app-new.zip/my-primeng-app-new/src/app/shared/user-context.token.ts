
// src/app/shared/user-context.token.ts
import { InjectionToken } from '@angular/core';

export interface UserContext {
  npi: string;
  officeId: string;
}

export const USER_CONTEXT = new InjectionToken<UserContext>('USER_CONTEXT');
