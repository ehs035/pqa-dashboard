
// src/app/shared/feedback.service.ts
import { Injectable, signal } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class FeedbackService {
  dialogOpen = signal(false);

  open()  { this.dialogOpen.set(true); }
  close() { this.dialogOpen.set(false); }
  toggle(){ this.dialogOpen.update(v => !v); }
}