
import { Routes } from '@angular/router';
import { LayoutComponent } from './layout/layout.component';

export const routes: Routes = [
  {
    path: '',
    component: LayoutComponent,
    children: [
      { path: '', redirectTo: 'survey', pathMatch: 'full' },
      {
        path: 'survey',
        loadComponent: () =>
          import('./survey/survey.component').then((m) => m.SurveyComponent),
      },
      // add other child routes here…
    ],
  },
  { path: '**', redirectTo: '' } // fallback
];
