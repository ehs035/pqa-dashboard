import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { catchError, map, shareReplay } from 'rxjs/operators';
import {
  SurveyData,
  SurveyQuestion,
  SurveyAnswer,
  AnswersFor,
  makeSurveyAnswer,
} from './survey.models';

@Injectable({ providedIn: 'root' })
export class SurveyService {
  private http = inject(HttpClient);
  private survey$?: Observable<SurveyData>;

  getCurrentSurvey(): Observable<SurveyData> {
    const url = 'assets/data/survey-data.json';
    return this.http.get<SurveyData>(url).pipe(
      map((data) => ({
        ...data,
        questions: sortByIndex(data.questions),
      })),
      catchError((err) => {
        console.error('Failed to load survey data:', err);
        return throwError(() => err);
      })
    );
  }

  getCurrentSurveyCached(): Observable<SurveyData> {
    if (!this.survey$) {
      this.survey$ = this.getCurrentSurvey().pipe(shareReplay(1));
    }
    return this.survey$!;
  }

  /**
   * Construct a strongly-typed SurveyAnswer from SurveyData.
   * Automatically includes surveyId, surveyName, description, surveyType.
   */
  buildAnswerFromSurvey<Qs extends readonly SurveyQuestion[]>(
    survey: SurveyData & { questions: Qs },
    input: {
      npi: string;
      officeId: string;
      submittedAt: string; // ISO
      responses: AnswersFor<Qs>;
    }
  ): SurveyAnswer<Qs> {
    const { surveyId, surveyName, description, surveyType, questions } = survey;
    return makeSurveyAnswer(questions, {
      surveyId,
      surveyName,
      description,
      surveyType,
      ...input,
    });
  }

  /** Optional runtime validator (same as before) */
  validateAnswer(
    questions: SurveyQuestion[],
    answer: SurveyAnswer<any>
  ): string[] {
    const issues: string[] = [];
    const responses = answer.responses ?? {};
    const qmap = new Map(questions.map((q) => [q.questionId, q]));

    for (const q of questions) {
      const value = (responses as Record<string, unknown>)[q.questionId];

      if (
        q.required &&
        (value === undefined || value === null || value === '')
      ) {
        issues.push(`${q.questionId}: Answer is required.`);
        continue;
      }
      if (value === undefined || value === null) continue;

      switch (q.questionType) {
        case 'Rating':
          if (typeof value !== 'number')
            issues.push(`${q.questionId}: Expected a number for Rating.`);
          break;

        case 'multilineText':
          if (typeof value !== 'string')
            issues.push(
              `${q.questionId}: Expected a string for multilineText.`
            );
          break;

        case 'select':
        case 'radioGroup': {
          const typeOk = typeof value === 'string' || typeof value === 'number';
          const optionsOk =
            !q.options || q.options.some((o) => o.value === value);
          if (!typeOk || !optionsOk)
            issues.push(`${q.questionId}: Invalid selection value.`);
          break;
        }

        case 'checkbox': {
          const isBool = typeof value === 'boolean';
          const isArray = Array.isArray(value);
          const elemsOk =
            !isArray ||
            (value as unknown[]).every(
              (v) => typeof v === 'string' || typeof v === 'number'
            );
          const optionsOk =
            !q.options ||
            (isBool
              ? true
              : (value as unknown[]).every((v) =>
                  q.options!.some((o) => o.value === v)
                ));
          if (!isBool && !(isArray && elemsOk && optionsOk))
            issues.push(`${q.questionId}: Invalid checkbox value.`);
          break;
        }

        case 'date': {
          const isIsoString =
            typeof value === 'string' && !isNaN(Date.parse(value));
          if (!isIsoString)
            issues.push(`${q.questionId}: Expected ISO date string.`);
          break;
        }

        case 'file': {
          const isStringArray =
            Array.isArray(value) && value.every((v) => typeof v === 'string');
          if (!isStringArray)
            issues.push(`${q.questionId}: Expected string[] (file IDs/URLs).`);
          break;
        }

        default:
          issues.push(
            `${q.questionId}: Unsupported question type: ${q.questionType}`
          );
      }
    }

    for (const key of Object.keys(responses)) {
      if (!qmap.has(key))
        issues.push(
          `${key}: Response does not match any question in this survey.`
        );
    }

    return issues;
  }

  /** Submit the survey answers to your backend */
  submitSurvey(payload: SurveyAnswer<any>): Observable<void> {
    // Replace with your real API endpoint
    // return this.http.post<void>('/api/surveys/submit', payload).pipe(
    //   catchError((err) => {
    //     console.error('Failed to submit survey answers:', err);
    //     return throwError(() => err);
    //   })
    // );

    return of(void 0);
  }

  clearCache() {
    (this as any).survey$ = undefined;
  }
}

function sortByIndex(questions: SurveyQuestion[]): SurveyQuestion[] {
  const cloned = [...questions];
  const withIndex = cloned.filter((q) => q.sortIndex !== undefined);
  const withoutIndex = cloned.filter((q) => q.sortIndex === undefined);

  withIndex.sort((a, b) => {
    const ai = a.sortIndex ?? Number.POSITIVE_INFINITY;
    const bi = b.sortIndex ?? Number.POSITIVE_INFINITY;
    return ai - bi;
  });

  return [...withIndex, ...withoutIndex];
}
