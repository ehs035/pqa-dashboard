
import { Component, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ButtonModule } from 'primeng/button';
import { SurveyDialogComponent } from './survey-dialog.component';

@Component({
  selector: 'app-survey',
  standalone: true,
  imports: [CommonModule, ButtonModule, SurveyDialogComponent],
  templateUrl: './survey.component.html'
})
export class SurveyComponent {
  // Grab the child dialog component so we can call its public method
  @ViewChild(SurveyDialogComponent) dialog!: SurveyDialogComponent;

  openDialog() {
    // Guard for safety in case the view isn't ready yet
    if (this.dialog && typeof this.dialog.toggleDialog === 'function') {
      this.dialog.toggleDialog();
    }
  }
}
