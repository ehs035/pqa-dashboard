
// src/app/survey/survey-defaults.loader.ts
import { Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { SurveyDefaultsConfig } from './survey-defaults.token';

@Injectable({ providedIn: 'root' })
export class SurveyDefaultsLoader {
  readonly config = signal<SurveyDefaultsConfig | null>(null);

  constructor(private http: HttpClient) {}

  // Cleaner async style (no deprecated .toPromise())
  async load(): Promise<void> {
    try {
      const cfg = await firstValueFrom(
        this.http.get<SurveyDefaultsConfig>('assets/survey-defaults.json')
      );
      this.config.set(cfg);
    } catch (err) {
      console.error('Failed to load survey defaults', err);
      this.config.set({ perType: {}, perQuestion: {} }); // safe fallback
    }
  }
}
