
// src/app/survey/survey-defaults.token.ts
import { InjectionToken } from '@angular/core';
import { SurveyQuestion } from './survey.models';

export type QuestionType =
  | 'Rating'
  | 'multilineText'
  | 'select'
  | 'radioGroup'
  | 'checkbox'
  | 'date'
  | 'file';

type DefaultInitializer =
  | unknown
  | ((q: SurveyQuestion) => unknown);

export interface SurveyDefaultsConfig {
  perType: Partial<Record<QuestionType, DefaultInitializer>>;
  perQuestion?: Record<string, DefaultInitializer>;
}

export const SURVEY_DEFAULTS = new InjectionToken<SurveyDefaultsConfig>('SURVEY_DEFAULTS');
