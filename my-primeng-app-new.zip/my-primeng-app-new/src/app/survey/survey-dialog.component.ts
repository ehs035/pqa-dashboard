import { Component, inject, signal, effect, DestroyRef } from '@angular/core';
import { CommonModule, NgComponentOutlet } from '@angular/common';
import {
  FormBuilder,
  FormGroup,
  Validators,
  ReactiveFormsModule,
  AbstractControl,
} from '@angular/forms';
import { DialogModule } from 'primeng/dialog';
import { ButtonModule } from 'primeng/button';
import { ProgressSpinnerModule } from 'primeng/progressspinner';

import { SurveyService } from './survey.service';
import { SurveyData, SurveyQuestion, SurveyAnswer } from './survey.models';
import { QUESTION_COMPONENTS } from './question-registry';
import { FeedbackService } from '../shared/feedback.service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

import { USER_CONTEXT } from '../shared/user-context.token';


@Component({
  selector: 'app-survey-dialog',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    DialogModule,
    ButtonModule,
    ProgressSpinnerModule,
    NgComponentOutlet,
  ],
  styleUrls: ['./survey-dialog.component.css'],
  templateUrl: './survey-dialog.component.html',
})
export class SurveyDialogComponent {
  private fb = inject(FormBuilder);
  private surveyService = inject(SurveyService);
  private feedback = inject(FeedbackService);
  private destroyRef = inject(DestroyRef);
  private readonly user = inject(USER_CONTEXT);

  // Signals for UI state
  showDialog = signal(false);
  isLoading = signal(false);
  hasError = signal(false);
  surveyData = signal<SurveyData | null>(null);

  // Reactive form: holds answers only, keyed by questionId
  surveyForm: FormGroup = this.fb.group({});

  constructor() {
    // React to shared feedback signal (from layout or other triggers)
    effect(() => {
      const open = this.feedback.dialogOpen();
      this.showDialog.set(open);

      // Lazy load survey data on first open
      if (open && !this.surveyData()) {
        this.loadSurvey();
      }
    });
  }

  /** Public: open/close via feedback service */
  toggleDialog() {
    this.feedback.toggle();
  }

  /** Public: Close via button in the dialog footer */
  closeDialog() {
    // ✅ Reset answers on close
    this.resetAnswerData();
    this.surveyService.clearCache();
    this.surveyData.set(null);
    this.feedback.close();
  }

  /**
   * Public: Keep the feedback signal in sync with PrimeNG's [visible] two-way binding.
   */
  onVisibleChange(visible: boolean) {
    this.feedback.dialogOpen.set(visible);

    if (visible && !this.surveyData()) {
      this.loadSurvey();
    }

    if (!visible) {
      // ✅ Reset answers when dialog is hidden
      this.resetAnswerData();
      this.surveyService.clearCache();
      this.surveyData.set(null);
      // this.surveyService.clearCache(); // optional if you cache
    }
  }

  /** Fetch survey data and build the form */
  private loadSurvey() {
    this.isLoading.set(true);
    this.hasError.set(false);

    this.surveyService
      .getCurrentSurvey()
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (data) => {
          this.surveyData.set(data);
          this.buildForm(data);
          this.isLoading.set(false);
        },
        error: () => {
          this.hasError.set(true);
          this.isLoading.set(false);
        },
      });
  }

  /** Build form controls based on questions */
  private buildForm(data: SurveyData) {
    const group: Record<string, any> = {};

    for (const q of data.questions) {
      const validators = this.validatorsFor(q);
      group[q.questionId] = this.fb.control(
        this.initialValueFor(q),
        validators
      );
    }

    this.surveyForm = this.fb.group(group);
  }

  /** Choose initial value per questionType */
  private initialValueFor(q: SurveyQuestion) {
    switch (q.questionType) {
      case 'Rating':
        // null to work well with required validator and number coercion
        return null;
      case 'multilineText':
        return '';
      case 'select':
      case 'radioGroup':
        return null; // user picks later
      // Uncomment/adjust when you add these types:
      // case 'checkbox':
      //   return [];   // multi-select by default; or false for single checkbox
      // case 'date':
      //   return '';   // ISO string
      // case 'file':
      //   return [];   // file IDs/URLs (after upload)
      default:
        return null;
    }
  }

  /** Validators per questionType */
  private validatorsFor(q: SurveyQuestion) {
    const base = q.required ? [Validators.required] : [];

    if (q.questionType === 'Rating') {
      // Optional: enforce 1–5 rating range
      const ratingRange = (ctl: AbstractControl) => {
        const v = ctl.value;
        if (v == null || v === '') return null; // let required handle empties
        const n = typeof v === 'number' ? v : Number(v);
        return Number.isFinite(n) && n >= 1 && n <= 5
          ? null
          : { ratingRange: true };
      };
      return [...base, ratingRange];
    }

    // You can add custom validators for other types (e.g., options membership)
    return base;
  }

  /** Resolve the component to render for a question type */
  componentFor(question: SurveyQuestion) {
    return QUESTION_COMPONENTS[question.questionType] ?? null;
  }

  /** Get the FormControl for a given question */
  controlFor(question: SurveyQuestion) {
    return this.surveyForm.get(question.questionId)!;
  }

  /** Validation helper used by the template */
  isControlInvalid(question: SurveyQuestion) {
    const ctl = this.surveyForm.get(question.questionId);
    return !!ctl && ctl.invalid && (ctl.touched || ctl.dirty);
  }

  /** Submit handler */
  onSubmit() {
    if (this.surveyForm.invalid) {
      this.surveyForm.markAllAsTouched();
      return;
    }

    const data = this.surveyData();
    if (!data) return;

    // Raw values from the form
    const raw = this.surveyForm.getRawValue();

    // Optional: coerce raw values to match expected answer types
    const coerced = this.coerceResponses(data.questions, raw);

    // Build a SurveyAnswer INCLUDING metadata: surveyId, surveyName, description, surveyType
    const answer: SurveyAnswer<any> = this.surveyService.buildAnswerFromSurvey(
      data,
      {
        npi: this.user.npi,
        officeId: this.user.officeId,
        submittedAt: new Date().toISOString(),
        responses: coerced,
      }
    );

    // Optional runtime schema validation (type/required/options)
    const issues = this.surveyService.validateAnswer(data.questions, answer);
    if (issues.length) {
      console.warn('Survey validation issues:', issues);
      this.surveyForm.markAllAsTouched();
      return;
    }

    this.isLoading.set(true);

    this.surveyService
      .submitSurvey(answer)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: () => {
          console.log('Survey submission payload:', answer);

          // ✅ Clear answers so next open starts fresh
          this.resetAnswerData();

          this.isLoading.set(false);
          this.feedback.close(); // close via shared service
        },
        error: () => {
          this.isLoading.set(false);
          this.hasError.set(true);
        },
      });
  }

  /**
   * Coerce raw form values to expected types per questionType.
   * Extend as you add more QuestionType values.
   */
  private coerceResponses(
    questions: SurveyQuestion[],
    raw: Record<string, any>
  ): Record<string, any> {
    const out: Record<string, any> = {};

    for (const q of questions) {
      const v = raw[q.questionId];

      switch (q.questionType) {
        case 'Rating':
          out[q.questionId] = v == null || v === '' ? null : Number(v);
          break;

        case 'multilineText':
          out[q.questionId] = v ?? '';
          break;

        case 'select':
        case 'radioGroup':
          // Assume UI components produce string|number aligned to option.value.
          out[q.questionId] = v;
          break;

        // Uncomment & adjust when you add these:
        // case 'checkbox':
        //   // If single checkbox: boolean
        //   // If multi-select: string[] or number[]
        //   out[q.questionId] = Array.isArray(v) ? v : !!v;
        //   break;

        // case 'date':
        //   // Normalize to ISO string
        //   out[q.questionId] = typeof v === 'string' ? v : (v?.toISOString?.() ?? '');
        //   break;

        // case 'file':
        //   // Convert File/File[] to uploaded IDs/URLs before submit
        //   out[q.questionId] = Array.isArray(v) ? v : (v ? [v] : []);
        //   break;

        default:
          out[q.questionId] = v;
      }
    }

    return out;
  }

  /** Build initial values per question type */
  private initialValuesFor(questions: SurveyQuestion[]): Record<string, any> {
    const initial: Record<string, any> = {};

    for (const q of questions) {
      initial[q.questionId] = this.initialValueFor(q);
    }

    return initial;
  }

  /** Reset the answers back to initial (empty) values */
  private resetAnswerData() {
    const data = this.surveyData();

    if (!data || !data.questions?.length) {
      // If survey data isn't loaded, just reset the form structure
      this.surveyForm.reset({});
      return;
    }

    // Reset form values to initial per QuestionType
    const initial = this.initialValuesFor(data.questions);
    this.surveyForm.reset(initial);

    // Also reset control state
    for (const q of data.questions) {
      const ctl = this.surveyForm.get(q.questionId);
      if (!ctl) continue;
      ctl.markAsPristine();
      ctl.markAsUntouched();
      ctl.updateValueAndValidity({ emitEvent: false });
    }
  }
}
