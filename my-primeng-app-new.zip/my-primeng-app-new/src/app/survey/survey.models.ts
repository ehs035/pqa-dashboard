
/**
 * Core survey models and dynamic answer typing
 */

export type QuestionType =
  | 'Rating'
  | 'multilineText'
  | 'select'
  | 'radioGroup'
  | 'checkbox'
  | 'date'
  | 'file';

/** Flexible survey ID to support numeric or string IDs (e.g., 'dev-exp-feedback-2024') */
export type SurveyId = string | number;

export interface SurveyOption<T = string | number | boolean> {
  label: string;
  value: T;
  disabled?: boolean;
}

export interface SurveyQuestion {
  questionId: string;
  title: string;
  description?: string;
  questionType: QuestionType;
  required?: boolean;
  sortIndex?: number; // controls display order
  options?: SurveyOption[];
  errorMessage?: string;
}

export type ISODateString = string;

/** Map question types to the stored answer value type */
export type ResponseValueFor<T extends QuestionType> =
  T extends 'Rating'         ? number :
  T extends 'multilineText'  ? string :
  T extends 'select'         ? string | number :
  T extends 'radioGroup'     ? string | number :
  T extends 'checkbox'       ? boolean | string[] | number[] :
  T extends 'date'           ? ISODateString :
  T extends 'file'           ? string[] :
  never;

/** Create responses shape based on the provided questions */
export type AnswersFor<Qs extends readonly SurveyQuestion[]> = {
  [Q in Qs[number] as Q['questionId']]: ResponseValueFor<Q['questionType']>;
};

/**
 * Answer payload you return/store — now includes the survey metadata.
 */
export interface SurveyAnswer<Qs extends readonly SurveyQuestion[] = SurveyQuestion[]> {
  surveyId: SurveyId;
  surveyName: string;
  description?: string;
  surveyType: string;

  npi: string;
  officeId: string;
  submittedAt: ISODateString;
  responses: AnswersFor<Qs>;
}

/** Survey container including its questions and metadata */
export interface SurveyData {
  surveyId: SurveyId;
  surveyName: string;
  description?: string;
  surveyType: string;
  questions: SurveyQuestion[];
}

/* Optional helper to enforce typing when constructing an answer */
export function makeSurveyAnswer<Qs extends readonly SurveyQuestion[]>(
  _questions: Qs,
  answer: SurveyAnswer<Qs>
): SurveyAnswer<Qs> {
  return answer;
}
