
import { Type } from '@angular/core';

import { RatingStarsQuestionComponent } from './questions/rating-question.component';
import { MultilineTextQuestionComponent } from './questions/multiline-text-question.component';
import { SelectQuestionComponent } from './questions/select-question.component';
import { RadioGroupQuestionComponent } from './questions/radio-group-question.component'; // <-- NEW


export const QUESTION_COMPONENTS: Record<string, Type<any>> = {
  Rating: RatingStarsQuestionComponent,
  multilineText: MultilineTextQuestionComponent,
  select: SelectQuestionComponent,
  radioGroup: RadioGroupQuestionComponent, 
  // checkbox: CheckboxQuestionComponent,
  // date: DateQuestionComponent,
  // file: FileQuestionComponent,
};