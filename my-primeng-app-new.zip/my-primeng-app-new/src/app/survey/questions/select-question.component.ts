
// src/app/survey/questions/select-question.component.ts
import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SelectModule } from 'primeng/select';
import { ReactiveFormsModule, FormControl } from '@angular/forms';
import { SurveyQuestion } from '../survey.models';
import { QuestionFieldComponent } from './question-field.component'; // <-- use your shell

@Component({
  selector: 'app-select-question',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, SelectModule, QuestionFieldComponent],
  template: `
    <app-question-field
      [question]="question"
      [control]="control"
      #field
    >
      <p-select
        class="w-full"
        [options]="question.options ?? []"
        optionLabel="label"
        optionValue="value"
        optionDisabled="disabled"
        [formControl]="control"
        [placeholder]="question.title"
        [showClear]="true"
        [filter]="true"
        [filterBy]="'label'"
        [attr.aria-labelledby]="field.headingId"
        [attr.aria-required]="question.required ? 'true' : null"
        [attr.aria-describedby]="question.description ? field.descriptionId : null"
      ></p-select>
    </app-question-field>
  `
})
export class SelectQuestionComponent {
  @Input({ required: true }) question!: SurveyQuestion;
  @Input({ required: true }) control!: FormControl<string | number>;
}
