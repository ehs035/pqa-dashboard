// src/app/survey/questions/multiline-text-question.component.ts
import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TextareaModule } from 'primeng/textarea';
import { ReactiveFormsModule, FormControl } from '@angular/forms';
import { SurveyQuestion } from '../survey.models';
import { QuestionFieldComponent } from './question-field.component'; // <-- adjust path

@Component({
  selector: 'app-multiline-text-question',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    TextareaModule,
    QuestionFieldComponent,
  ],
  template: `
    <app-question-field [question]="question" [control]="control" #field>
      <textarea
        pInputTextarea
        [formControl]="control"
        rows="4"
        autoResize="true"
        class="w-full rounded border border-gray-300 p-2"
        fluid
        [attr.aria-labelledby]="field.headingId"
        [attr.aria-required]="question.required ? 'true' : null"
        [attr.aria-describedby]="
          question.description ? field.descriptionId : null
        "
      ></textarea>
    </app-question-field>
  `,
})
export class MultilineTextQuestionComponent {
  @Input({ required: true }) question!: SurveyQuestion;
  @Input({ required: true }) control!: FormControl<string | null>;
}
