// src/app/survey/questions/rating-stars-question.component.ts
import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RatingModule } from 'primeng/rating';
import { ReactiveFormsModule, FormControl } from '@angular/forms';
import { SurveyQuestion } from '../survey.models';
import { QuestionFieldComponent } from './question-field.component'; // adjust path

@Component({
  selector: 'app-rating-stars-question',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RatingModule,
    QuestionFieldComponent,
  ],
  template: `
    <app-question-field [question]="question" [control]="control" #field>
      <p-rating
        [formControl]="control"
        [attr.aria-labelledby]="field.headingId"
        [attr.aria-required]="question.required ? 'true' : null"
        [attr.aria-describedby]="
          question.description ? field.descriptionId : null
        "
      ></p-rating>
    </app-question-field>
  `,
})
export class RatingStarsQuestionComponent {
  @Input({ required: true }) question!: SurveyQuestion;
  @Input({ required: true }) control!: FormControl<number | null>;
}
