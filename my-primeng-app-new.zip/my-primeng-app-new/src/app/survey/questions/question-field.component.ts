
// src/app/survey/components/question-field.component.ts
import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormControl } from '@angular/forms';
import { SurveyQuestion } from '../survey.models';

@Component({
  selector: 'app-question-field',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div class="space-y-2">
      <h4 class="text-base font-semibold p-text-color" [id]="headingId">
        {{ question.title }}
        @if (question.required) {
          <span class="text-danger" aria-hidden="true">*</span>
        }
      </h4>

      @if (question.description) {
        <p
          class="text-sm p-text-color-secondary"
          [id]="descriptionId"
        >
          {{ question.description }}
        </p>
      }

      <!-- Project the actual control (rating, number, textarea, select, radios, etc.) -->
      <ng-content></ng-content>

      @if (isInvalid()) {
        <small class="text-xs p-text-danger" role="alert">
          {{ question.errorMessage || 'Please enter a valid value.' }}
        </small>
      }
    </div>
  `
})
export class QuestionFieldComponent {
  @Input({ required: true }) question!: SurveyQuestion;
  @Input({ required: true }) control!: FormControl<any>; // supports any control type

  get headingId() { return `q_${this.question.questionId}_label`; }
  get descriptionId() { return `q_${this.question.questionId}_desc`; }

  isInvalid() {
    return this.control.invalid && (this.control.touched || this.control.dirty);
  }
}
