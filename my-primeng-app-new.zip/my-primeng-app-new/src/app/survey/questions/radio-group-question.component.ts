
// src/app/survey/questions/radio-group-question.component.ts
import {
  Component,
  ChangeDetectionStrategy,
  computed,
  input,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormControl } from '@angular/forms';
import { RadioButtonModule, RadioButtonClickEvent } from 'primeng/radiobutton';
import { SurveyQuestion, SurveyOption } from '../survey.models';
import { QuestionFieldComponent } from './question-field.component';

@Component({
  selector: 'app-radio-group-question',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RadioButtonModule, QuestionFieldComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <app-question-field
      [question]="question()"
      [control]="control()"
      #field
    >
      <div
        class="flex flex-col gap-3"
        role="radiogroup"
        [attr.aria-labelledby]="field.headingId"
        [attr.aria-required]="question().required ? 'true' : null"
        [attr.aria-describedby]="question().description ? field.descriptionId : null"
      >
        <ng-container
          *ngFor="let opt of question().options ?? []; trackBy: trackByValue"
        >
          <div
            class="flex items-center"
            [class.option-disabled]="opt.disabled"
          >
            <p-radioButton
              [name]="groupName()"
              [inputId]="idFor(opt.value)"
              [formControl]="control()"
              [value]="opt.value"
              [attr.disabled]="opt.disabled ? true : null"
              (onClick)="handleOptionClick(opt, $event)"
            ></p-radioButton>

            <label class="ml-2" [for]="idFor(opt.value)">
              {{ opt.label }}
            </label>
          </div>
        </ng-container>
      </div>
    </app-question-field>
  `,
  styles: [
    `
      .option-disabled {
        opacity: 0.6;
        pointer-events: none; /* prevent label clicks from focusing/selecting */
      }
    `,
  ],
})
export class RadioGroupQuestionComponent {
  readonly question = input.required<SurveyQuestion>();
  readonly control = input.required<FormControl<string | number | boolean>>();

  readonly groupName = computed(() => `q_${this.question().questionId}`);

  idFor = (val: unknown) => `${this.groupName()}_${String(val)}`;
  trackByValue = (_: number, opt: { value: unknown }) => opt.value;

  handleOptionClick(
    opt: SurveyOption<string | number | boolean>,
    event: RadioButtonClickEvent
  ): void {
    if (opt.disabled) {
      event.originalEvent?.preventDefault();
      event.originalEvent?.stopPropagation();
    }
  }
}
