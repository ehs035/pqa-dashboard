
// src/app/survey/survey-defaults.resolver.ts
import { inject } from '@angular/core';
import { SURVEY_DEFAULTS, SurveyDefaultsConfig } from './survey-defaults.token';
import { SurveyQuestion } from './survey.models';

function resolveDynamic(value: unknown): unknown {
  if (value === 'NOW_ISO') return new Date().toISOString();
  return value;
}

export function resolveInitialValue(q: SurveyQuestion): unknown {
  const cfg = inject(SURVEY_DEFAULTS) as SurveyDefaultsConfig;

  const perQ = cfg.perQuestion?.[q.questionId];
  if (typeof perQ === 'function') return (perQ as (q: SurveyQuestion) => unknown)(q);
  if (perQ !== undefined) return resolveDynamic(perQ);

  const perT = cfg.perType[q.questionType as keyof SurveyDefaultsConfig['perType']];
  if (typeof perT === 'function') return (perT as (q: SurveyQuestion) => unknown)(q);
  if (perT !== undefined) return resolveDynamic(perT);

  return null;
}
