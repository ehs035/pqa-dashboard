import {
  ApplicationConfig,
  provideZoneChangeDetection,
  inject,
  provideAppInitializer
} from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { provideHttpClient } from '@angular/common/http';
import { providePrimeNG } from 'primeng/config';
import Aura from '@primeng/themes/aura';
import { routes } from './app.routes';

import { SURVEY_DEFAULTS } from '../app/survey/survey-defaults.token';
import { SurveyDefaultsLoader } from '../app/survey/survey-defaults.loader';
import { USER_CONTEXT, UserContext } from './shared/user-context.token';

function initSurveyDefaults() {
  const loader = inject(SurveyDefaultsLoader);
  return () => loader.load(); // Promise<void>
}

const userContext: UserContext = {
  npi: 'user123', // replace with values from your auth/tenant config
  officeId: 'office789',
};

export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes),
    { provide: USER_CONTEXT, useValue: userContext },
    provideAnimationsAsync(),
    provideHttpClient(),
    providePrimeNG({
      ripple: true,
      theme: {
        preset: Aura,
        options: { prefix: 'p', cssLayer: true },
      },
    }),

   
 // ✅ Angular 18/19+ initializer (injection context is the arrow function)
    provideAppInitializer(() => {
      const loader = inject(SurveyDefaultsLoader);
      // Returning a Promise/Observable makes Angular wait before completing bootstrap
      return loader.load();
    }),

  ],
};
