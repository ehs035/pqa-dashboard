import {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
} from "./chunk-26COGDWH.js";
import "./chunk-PNYIASC5.js";
import "./chunk-EXNV7EVD.js";
import "./chunk-XJ5UJXXH.js";
import "./chunk-3ND6JP2Y.js";
import "./chunk-WPM5VTLQ.js";
import "./chunk-PEBH6BBU.js";
import "./chunk-4S3KYZTJ.js";
import "./chunk-WDMUDEB6.js";
export {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
};
